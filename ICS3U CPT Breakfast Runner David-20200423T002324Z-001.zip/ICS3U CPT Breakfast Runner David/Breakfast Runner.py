# CPT: Breakfast Runner game
# @author David Guo
# @author Arunesh Baskaran
# @course ICS3UC
# @date 2019/01/23

# Graphics template taken from programarcadegames.com

# Importing Modules
import pygame
import random
import math

# Setting up dimensions of the screen and framerate
WIDTH = 1280
HEIGHT = 720
FPS = 60

# Define constants
WHITE = (255,255,255)
BLACK = (0,0,0  )
PI = 3.1415

# Global index of screen movement
global acceleration
acceleration = 0

### Classes

class Player(pygame.sprite.Sprite):
     # Sprite for the player
    def __init__(self):
        # Create player image, get rect, and create a mask for collision
        pygame.sprite.Sprite.__init__(self)

        # Set up initial variables for position and rect
        # Set up crouching
        self.crouching = False

        # Create bool value to track jumps
        self.isJumping = False

        # Load standing/standard image and get rect
        self.image1 = playerImgs[0]
        self.rect1 = self.image1.get_rect()

        #Load crouching image and get rect
        self.image2 = playerImgs[1]
        self.rect2 = self.image2.get_rect()

        # Set initial image and rect to standing
        self.image = self.image1
        self.rect = self.rect1

        # Create a pixel mask for more accurate collision
        self.mask = pygame.mask.from_surface(self.image)

        # Defining coordinates for collision
        self.rect.center = (300, 580)
        self.rect.bottom = 620

        # Defining variables for jumping
        # Velocity in the y axis
        self.vy = 14

        # Mass to determine jump height and falling speed
        self.mass = 0.6

        # Acceleration due to jumping motion and gravity (this is actually force)
        self.accely = 0

    def update(self):
        # Handle crouching
        if self.crouching and self.isJumping is False:
            self.image = self.image2
            # Set a position to be drawn to
            self.rect2.center = (300, 580)
            self.rect2.bottom = 620

            # Set the rect to the crouching rect
            self.rect = self.rect2
            # Create a mask for accurate collision
            self.mask = pygame.mask.from_surface(self.image)

        # Redraw the initial image state
        else:
            self.image = self.image1
            self.rect = self.rect1
            self.mask = pygame.mask.from_surface(self.image)

        # Determine what to do if player is jumping
        if self.isJumping:
            # If player is moving upwards
            # Calculate acceleration (or force, in reality)
            if self.vy > 0:
                self.accely = 0.5 * self.mass * self.vy ** 2
            else:
                # Calculate effects of gravity
                self.accely = -0.0712 * self.mass * self.vy ** 2
            # Change position
            self.rect.y -= self.accely
            # Change velocity for descent
            self.vy = self.vy - 1

    def shoot(self):
        # http://programarcadegames.com/python_examples/show_file.php?file=bullets_aimed.py
        # Shoot method (called when user clicks mouse)
        # Get mouse position
        pos = pygame.mouse.get_pos()
        mouse_x = pos[0]
        mouse_y = pos[1]

        # Finding displacement between mouse position and player rect
        x_diff = mouse_x - self.rect.x
        y_diff = mouse_y - self.rect.y

        # Taking the angle
        angle = math.atan2(x_diff, y_diff)

        # Restricting field of aim (so that the butter and fork obstacles are not removable by bullets)
        # Restricting angle of aim to above abs(120 degrees)
        if angle > 120*PI/180 or angle < -120*PI/180:
            # Create an instance of a bullet
            # Calls bullet class
            bullet = Bullet(player.rect.x + random.randint(5,10), player.rect.y, mouse_x, mouse_y)
            # Add the bullet to all sprites list and projectiles list
            all_sprites.add(bullet)
            projectiles.add(bullet)

        # Allow the player to shoot anywhere if jumping
        elif self.isJumping:
            bullet = Bullet(player.rect.x + random.randint(5,10), player.rect.y, mouse_x, mouse_y)
            all_sprites.add(bullet)
            projectiles.add(bullet)

class Enemy(pygame.sprite.Sprite):
    # Basic outline for enemy objects
    def __init__(self, x, y):
        # Get image
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.image.load("Blank.png").convert_alpha()

        # Get rect
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y
        self.vx = 10

    def update(self):
        # Set initial velocity (this will act as the world index/velocity)
        # New update method that factors in acceleration
        # acceleration is a global variable that increases the speed of objects with every bullet collision
        self.rect.x -= self.vx + acceleration

class Fork(Enemy):
    # First enemy (horizontal motion fork)
    def __init__(self):
        # Load image to position
        super().__init__(random.randint(1280, 1400), 500)
        self.image = forkImg
        self.mask = pygame.mask.from_surface(self.image)

class Butter(Enemy):
    # Second enemy (faster horizontal motion butter with random y position)
    def __init__(self):
        # Load image to position
        super().__init__(1300, random.randint(480, 520))
        self.image = butterImg
        self.mask = pygame.mask.from_surface(self.image)
        self.vx = 16

class Orange(Enemy):
    # Third enemy (erratic vertical motion orange juice drop with random x and y position)
    def __init__(self):
        # Load image to random position
        super().__init__(random.randint(100, 1180), random.randint(-200, 0))
        self.image = orangeImg
        self.mask = pygame.mask.from_surface(self.image)
        self.vx = random.randint(-1,3)

    # New update method with random x and y velocity
    def update(self):
        self.rect.x += random.randint(-3, 1)
        self.rect.y += random.randint(2, 5)


class Erratic(pygame.sprite.Sprite):
    # Code takes design ideas from
    # http://programarcadegames.com/python_examples/show_file.php?file=sprite_circle_movement.py
    # Fourth enemy (erratic wave motion apple with random x and y position)
    def __init__(self):
        # Load image
        pygame.sprite.Sprite.__init__(self)
        self.image = appleImg
        self.mask = pygame.mask.from_surface(self.image)
        self.rect = self.image.get_rect()

        # Set random x location and y center for sine motion
        self.rect.x = random.randint(WIDTH, 1400)
        self.center_y = random.randint(0, HEIGHT - 260)
        # Get the angle in terms of radians
        self.angle = random.random() * 2 * math.pi
        # Random distance to center of motion
        self.radius = random.randint(10, 30)
        # Speed of vertical motion in radians per frame
        self.speed = random.uniform(0.09, 0.3)

    def update(self):
        # Update method
        # Motion in x direction with acceleration
        self.rect.x -= 8 + 0.5 * acceleration
        # "Orbiting" motion in y direction
        self.rect.y = self.radius * math.cos(self.angle) + self.center_y

        # Increase the angle, changes the direction
        self.angle += self.speed


class Bullet(pygame.sprite.Sprite):
    # Projectile created at player location (created in shoot method of player)
    def __init__(self, start_x, start_y, dest_x, dest_y):
        # Get image
        pygame.sprite.Sprite.__init__(self)
        self.image = bagelImg
        self.mask = pygame.mask.from_surface(self.image)
        self.rect = self.image.get_rect()

        # Define starting point
        self.rect.x = start_x
        self.rect.y = start_y

        # Floating point values for more accuracy when aiming
        self.floating_point_x = start_x
        self.floating_point_y = start_y

        # Calculating the angle between the starting point of the bullet and its destination in radians

        x_diff = dest_x - start_x
        y_diff = dest_y - start_y
        angle = math.atan2(y_diff, x_diff)

        # Taking into account the angle, calculate our change_x and change_y. Velocity is how fast the bullet travels.
        velocity = 13
        self.change_x = math.cos(angle) * velocity
        self.change_y = math.sin(angle) * velocity

    def update(self):
        # The floating point x and y hold our more accurate location.
        self.floating_point_y += self.change_y
        self.floating_point_x += self.change_x

        # The rect.x and rect.y are converted to integers.
        self.rect.y = int(self.floating_point_y)
        self.rect.x = int(self.floating_point_x)

        # If the bullet flies of the screen, get rid of it.
        if self.rect.x < 0 or self.rect.x > WIDTH or self.rect.y < 0 or self.rect.y > HEIGHT:
            self.kill()

class Ground(pygame.sprite.Sprite):
    # Ground object
    def __init__(self, x, y, w, h):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.transform.scale(groundImg, (w,h))
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y

    def update(self):
        self.rect.x -= 10 + acceleration
        if self.rect.right < 0:
            self.kill()

### Main
# initialize pygame and create window
pygame.init()
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Breakfast Runner")
clock = pygame.time.Clock()

# Load graphics
playerImgs = [pygame.image.load("Toaster.png").convert_alpha(), pygame.image.load("Toaster Crouch.png").convert_alpha()]
forkImg = pygame.image.load("Fork.png").convert_alpha()
appleImg = pygame.image.load("Apple.png").convert_alpha()
butterImg = pygame.image.load("Butter.png").convert_alpha()
orangeImg = pygame.image.load("Orange.png").convert_alpha()
bagelImg = pygame.image.load("Bagel.png").convert_alpha()
backgroundImg = pygame.image.load("Background.png").convert_alpha()
extraLifeImg = pygame.image.load("Extra Life.png").convert_alpha()
groundImg = pygame.image.load("Wood.jpg").convert_alpha()

# Create sprite lists and adding initial sprites (player and ground)
all_sprites = pygame.sprite.Group()
players = pygame.sprite.Group()
platforms = pygame.sprite.Group()
enemies = pygame.sprite.Group()
projectiles = pygame.sprite.Group()

player = Player()
players.add(player)

groundVisible = Ground(WIDTH, HEIGHT - 100, 2560, 720)
all_sprites.add(groundVisible)
platforms.add(groundVisible)

# Initializing tracking variables
index = 0
score = 0
scoreMultiplier = 1
key_s = False

# Setting the font
font = pygame.font.SysFont('Calibri', 23 , True, False)

# Defining the game over screen
def showGameOver():
    # Create rectangle
    pygame.draw.rect(screen, BLACK,[200,80,880,560],0)

    # Check if user has played before
    if score > 0:
        endGame = font.render("GAME OVER!", True, WHITE)
        screen.blit(endGame, (570, HEIGHT/4))
        displayScore = font.render("SCORE: " + str(score), True, WHITE)
        screen.blit(displayScore, (570, HEIGHT/6))

    # Display title and instructions
    title = font.render("Breakfast Runner", True, WHITE)
    screen.blit(title, (560, HEIGHT / 3))

    instructions = font.render("Mouse click to shoot, W to jump, S to crouch Mouse to aim, Press a key to begin.", True, WHITE)
    screen.blit(instructions, (250, HEIGHT / 2))

    tips = font.render("Hitting objects increases your score, but makes the game more difficult!", True, WHITE)
    screen.blit(tips, (280, 3*HEIGHT/4))

done = False
gameOver = True

### Game loop
while not done:
    # keep loop running at the right speed
    clock.tick(FPS)
    # Process input (events)
    for event in pygame.event.get():
        # check if game over
        if gameOver:
            # Allow the user to quit
            if event.type == pygame.QUIT:
                pygame.quit()
            # Start the game if user presses a key
            if event.type == pygame.KEYUP:
                # Score must be reset after game over screen is shown, otherwise score won't be displayed
                score = 0

                #Set gameOver to false
                gameOver = False
        # If not game over, proceed as usual
        else:
            # Check if user has quit
            if event.type == pygame.QUIT:
                done = True
            # Check if user has pressed w to jump
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_w:
                    player.isJumping = True
                # Check if user has pressed s to crouch
                if event.key == pygame.K_s:
                    key_s = True
            if event.type == pygame.KEYUP:
                # Check if user has let go of s and stopped crouching
                if event.key == pygame.K_s:
                    key_s = False

            # Check if user has clicked to shoot
            elif event.type == pygame.MOUSEBUTTONDOWN:
                player.shoot()

    # Manage crouch based on key pres
    if key_s:
        player.crouching = True
    else:
        player.crouching = False

    # Updates
    all_sprites.update()

    # Keep creating ground sprites
    if groundVisible.rect.left < 1:
        groundVisible = Ground(WIDTH, HEIGHT - 100, 2560, 720)
        all_sprites.add(groundVisible)
        platforms.add(groundVisible)

    # Save memory by removing any ground sprites that go off screen
    if groundVisible.rect.right < 1:
        groundVisible.kill()

    # Spawn enemies after a set amount of distance and time (tracked by index variable)
    # Spawn fork
    if index % 200 == 0 and index > 50:
        for i in range(random.randint(1,3)):
            fork = Fork()
            all_sprites.add(fork)
            enemies.add(fork)

    # Create instance butter
    if index % 120 < 1 and index > 200:
        butter = Butter()
        all_sprites.add(butter)
        enemies.add(butter)

    # Create instance apple
    if index > 450 and index % 200 == 0:
        for i in range(4):
            apple = Erratic()
            all_sprites.add(apple)
            enemies.add(apple)

    # Create instance orange
    if index % 120 == 0 and index > 800:
        for i in range(4):
            orange = Orange()
            all_sprites.add(orange)
            enemies.add(orange)

    # Increase the index (timer)
    index += 1

    # Checking if player is on the ground
    touchingGround = pygame.sprite.spritecollide(player, platforms, False)
    if touchingGround:
        # Collision checks

        # Reset position and jumping variables if player makes contact with ground
        player.isJumping = False
        player.vy = 14
        player.accely = 0
        player.rect.bottom = 620

    # Checking if the player has hit any enemies
    playerHits = pygame.sprite.spritecollide(player, enemies, False, pygame.sprite.collide_mask)
    if playerHits :
        # Remove the player from all sprite lists and set bool value gameOver to true in order to call game over screen
        player.kill()
        gameOver = True

    # Checking if player fired bullets have hit any enemies
    bulletHits = pygame.sprite.groupcollide(projectiles, enemies, True, True, pygame.sprite.collide_mask)
    for hit in bulletHits:
        scoreMultiplier += 1
        acceleration += 0.1
        index += 1

    if gameOver:
        # Determine what to do if the player dies
        # Show the game over screen (calling function)
        showGameOver()

        # Reinitialize initial sprites
        all_sprites = pygame.sprite.Group()
        platforms = pygame.sprite.Group()
        enemies = pygame.sprite.Group()
        projectiles = pygame.sprite.Group()

        player = Player()
        all_sprites.add(player)
        # If player died while crouching, ensure that the sprite returns to its initial state
        key_s = False

        groundVisible = Ground(0, HEIGHT - 100, 2560, 720)
        all_sprites.add(groundVisible)
        platforms.add(groundVisible)

        # Reset acceleration value
        acceleration = 0

        # Reset tracking variables
        index = 0
        scoreMultiplier = 1
    else:
        # Draw / render as per normal
        screen.fill(BLACK)
        screen.blit(backgroundImg, (0, 0))

        # Scoreboard
        score += scoreMultiplier

        pygame.draw.rect(screen, WHITE, [1080, 40, 200, 40], 2)
        text = font.render("SCORE: " + str(score), True, WHITE)
        screen.blit(text, [1100, 50])

        # Drawing all sprites
        all_sprites.draw(screen)

        # Setting game over to false so that the game over screen doesn't trigger
        gameOver = False

    # After drawing everything, flip the display
    pygame.display.flip()

# Exit the game when done
pygame.quit()
